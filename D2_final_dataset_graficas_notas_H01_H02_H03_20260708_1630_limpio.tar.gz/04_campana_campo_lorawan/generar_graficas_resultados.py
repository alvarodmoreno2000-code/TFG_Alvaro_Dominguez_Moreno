# ============================================================
# Script: generar_graficas_resultados.py
# Objetivo:
#   Generar las gráficas principales de la campaña LoRaWAN
#   a partir del dataset final y del resumen estadístico.
#
# Entrada:
#   05_resultados/dataset_lorawan_R01_H01_H02_H03_gateway_propio.csv
#   05_resultados/resumen_estadistico_R01_H01_H02_H03.csv
#
# Salida:
#   Imágenes PNG con gráficas RSSI/SNR y número de muestras.
# ============================================================

import csv
from pathlib import Path
from collections import defaultdict
import matplotlib.pyplot as plt


# ------------------------------------------------------------
# Definición de rutas de trabajo
# ------------------------------------------------------------

# Carpeta base del proyecto. El script se ejecuta desde:
# ~/tfg_lora/04_campana_campo_lorawan
base = Path(".")

# Carpeta donde se encuentran el dataset final y el resumen estadístico
resultados = base / "05_resultados"

# Dataset final filtrado por gateway propio
dataset_path = resultados / "dataset_lorawan_R01_H01_H02_H03_gateway_propio.csv"

# Resumen estadístico generado previamente
summary_path = resultados / "resumen_estadistico_R01_H01_H02_H03.csv"


# ------------------------------------------------------------
# Lectura del resumen estadístico
# ------------------------------------------------------------
# Este CSV contiene una fila por posición de medida:
# H01, H02 y H03.
#
# Se extraen:
#   - RSSI medio por posición
#   - SNR medio por posición
#   - número de muestras útiles por posición
# ------------------------------------------------------------

posiciones = []
rssi_medios = []
snr_medios = []
muestras = []

with summary_path.open(newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for row in reader:
        posiciones.append(row["posicion"])
        rssi_medios.append(float(row["rssi_medio_dbm"]))
        snr_medios.append(float(row["snr_medio_db"]))
        muestras.append(int(row["muestras_gateway_propio"]))


# ------------------------------------------------------------
# Gráfica 1: RSSI medio por posición
# ------------------------------------------------------------
# Permite comparar la potencia media recibida en H01, H02 y H03.
# Valores menos negativos indican mejor nivel de señal.
# ------------------------------------------------------------

plt.figure()
plt.bar(posiciones, rssi_medios)
plt.xlabel("Posición de medida")
plt.ylabel("RSSI medio (dBm)")
plt.title("RSSI medio por posición")
plt.grid(axis="y")
plt.tight_layout()
plt.savefig(resultados / "grafica_rssi_medio_por_posicion.png", dpi=300)
plt.close()


# ------------------------------------------------------------
# Gráfica 2: SNR medio por posición
# ------------------------------------------------------------
# Permite comparar la calidad media del enlace radio.
# Valores positivos indican una recepción más favorable.
# Valores negativos indican condiciones de enlace más exigentes.
# ------------------------------------------------------------

plt.figure()
plt.bar(posiciones, snr_medios)
plt.xlabel("Posición de medida")
plt.ylabel("SNR medio (dB)")
plt.title("SNR medio por posición")
plt.grid(axis="y")
plt.tight_layout()
plt.savefig(resultados / "grafica_snr_medio_por_posicion.png", dpi=300)
plt.close()


# ------------------------------------------------------------
# Lectura del dataset completo
# ------------------------------------------------------------
# El dataset contiene una fila por trama útil recibida por
# el gateway propio loragateway-tfgalvaro.
#
# Se agrupan las muestras por posición para representar
# la evolución de RSSI y SNR frente al contador de trama FCnt.
# ------------------------------------------------------------

datos = defaultdict(list)

with dataset_path.open(newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for row in reader:
        pos = row["posicion"]

        # Algunas filas pueden no contener contador de trama o métricas
        # radioeléctricas completas. Esto puede ocurrir si en el CSV
        # aparece algún evento auxiliar, una fila incompleta o un registro
        # no útil para la representación temporal.
        #
        # Para evitar errores al convertir a int/float, se descartan
        # únicamente esas filas incompletas. El análisis principal se
        # mantiene sobre las tramas válidas del dataset.
        if not row.get("f_cnt") or not row.get("rssi") or not row.get("snr"):
            continue

        datos[pos].append({
            "f_cnt": int(row["f_cnt"]),
            "rssi": float(row["rssi"]),
            "snr": float(row["snr"]),
        })


# ------------------------------------------------------------
# Gráfica 3: evolución del RSSI por muestra
# ------------------------------------------------------------
# Representa el RSSI de cada trama recibida en función del FCnt.
# Permite observar la estabilidad o variación de la señal dentro
# de cada posición de medida.
# ------------------------------------------------------------

plt.figure()

for pos, rows in datos.items():
    # Ordenamos las muestras por contador de trama
    rows = sorted(rows, key=lambda x: x["f_cnt"])

    plt.plot(
        [r["f_cnt"] for r in rows],
        [r["rssi"] for r in rows],
        marker="o",
        label=pos
    )

plt.xlabel("Contador de trama FCnt")
plt.ylabel("RSSI (dBm)")
plt.title("Evolución del RSSI por posición")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig(resultados / "grafica_rssi_por_muestra.png", dpi=300)
plt.close()


# ------------------------------------------------------------
# Gráfica 4: evolución del SNR por muestra
# ------------------------------------------------------------
# Representa el SNR de cada trama recibida en función del FCnt.
# Permite visualizar la degradación de la calidad del enlace
# entre las posiciones H01, H02 y H03.
# ------------------------------------------------------------

plt.figure()

for pos, rows in datos.items():
    # Ordenamos las muestras por contador de trama
    rows = sorted(rows, key=lambda x: x["f_cnt"])

    plt.plot(
        [r["f_cnt"] for r in rows],
        [r["snr"] for r in rows],
        marker="o",
        label=pos
    )

plt.xlabel("Contador de trama FCnt")
plt.ylabel("SNR (dB)")
plt.title("Evolución del SNR por posición")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig(resultados / "grafica_snr_por_muestra.png", dpi=300)
plt.close()


# ------------------------------------------------------------
# Gráfica 5: número de muestras útiles por posición
# ------------------------------------------------------------
# Muestra cuántas tramas válidas se conservaron en el dataset
# tras filtrar únicamente el gateway propio.
# ------------------------------------------------------------

plt.figure()
plt.bar(posiciones, muestras)
plt.xlabel("Posición de medida")
plt.ylabel("Número de muestras útiles")
plt.title("Muestras útiles por posición")
plt.grid(axis="y")
plt.tight_layout()
plt.savefig(resultados / "grafica_muestras_por_posicion.png", dpi=300)
plt.close()


# ------------------------------------------------------------
# Mensaje final de confirmación
# ------------------------------------------------------------

print("[OK] Graficas generadas en 05_resultados/")
